package ru.mapublish.multiplicationtable

class Constants {
    companion object {
        val PRODUCTS_STAGE_ONE = mutableListOf(1, 2, 2, 4)
        val PRODUCTS_STAGE_TWO = mutableListOf(1, 2, 2, 3, 3, 4, 6, 6, 9)
    }
}