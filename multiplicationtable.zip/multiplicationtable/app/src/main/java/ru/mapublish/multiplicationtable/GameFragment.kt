package ru.mapublish.multiplicationtable


import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProvider
import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.lifecycle.ViewModelProviders
import ru.mapublish.multiplicationtable.databinding.FragmentGameBinding

/**
 * Fragment where the game is played
 */
class GameFragment : Fragment() {

    private lateinit var binding: FragmentGameBinding
    private lateinit var viewModel: GameViewModel

    //lists of TextViews in which factors and their products are shown to the player
    private val productBoxes = listOf(
        binding.rI1,
        binding.rI2,
        binding.rI3,
        binding.rI4,
        binding.rI5,
        binding.rI6,
        binding.rI7,
        binding.rI8,
        binding.rI9,
        binding.rII2,
        binding.rII4,
        binding.rII6,
        binding.rII8,
        binding.rII10,
        binding.rII12,
        binding.rII14,
        binding.rII16,
        binding.rII18,
        binding.rIII3,
        binding.rIII6,
        binding.rIII9,
        binding.rIII12,
        binding.rIII15,
        binding.rIII18,
        binding.rIII21,
        binding.rIII24,
        binding.rIII27,
        binding.rIV4,
        binding.rIV8,
        binding.rIV12,
        binding.rIV16,
        binding.rIV20,
        binding.rIV24,
        binding.rIV28,
        binding.rIV32,
        binding.rIV36,
        binding.rV5,
        binding.rV10,
        binding.rV15,
        binding.rV20,
        binding.rV25,
        binding.rV30,
        binding.rV35,
        binding.rV40,
        binding.rV45,
        binding.rVI6,
        binding.rVI12,
        binding.rVI18,
        binding.rVI24,
        binding.rVI30,
        binding.rVI36,
        binding.rVI42,
        binding.rVI48,
        binding.rVI54,
        binding.rVII7,
        binding.rVII14,
        binding.rVII21,
        binding.rVII28,
        binding.rVII35,
        binding.rVII42,
        binding.rVII49,
        binding.rVII56,
        binding.rVII63,
        binding.rVIII8,
        binding.rVIII16,
        binding.rVIII24,
        binding.rVIII32,
        binding.rVIII40,
        binding.rVIII48,
        binding.rVIII56,
        binding.rVIII64,
        binding.rVIII72,
        binding.rIX9,
        binding.rIX18,
        binding.rIX27,
        binding.rIX36,
        binding.rIX45,
        binding.rIX54,
        binding.rIX63,
        binding.rIX72,
        binding.rIX81
    )
    private val factorBoxes = listOf(
        binding.rI,
        binding.rII,
        binding.rIII,
        binding.rIV,
        binding.rV,
        binding.rVI,
        binding.rVII,
        binding.rVIII,
        binding.rIX,
        binding.cI,
        binding.cII,
        binding.cIII,
        binding.cIV,
        binding.cV,
        binding.cVI,
        binding.cVII,
        binding.cVIII,
        binding.cIX
    )


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

//         inflates view and obtains an instance of the binding class
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_game, container, false)

//        viewModel = ViewModelProviders.of(this).get(GameViewModel::class.java)

//        binding.gameViewModel = viewModel
//        binding.lifecycleOwner = this

        viewModel.product.observe(this, Observer { product ->
            showProductInTheTable(product)
        })

        viewModel.correct.observe(this, Observer { correct ->
            //            if (correct) //TODO onCorrectAnswer()
//                else //TODO onWrongAnswer()
        })


        return binding.root
    }


    private fun showProductInTheTable(product: Int?) {
        when (product) {
            1 -> binding.rI1.text = viewModel.product.toString()
        }
    }


    fun clearTheTable() {
        for (element in productBoxes) {
            element.text = ""
        }
    }
}
