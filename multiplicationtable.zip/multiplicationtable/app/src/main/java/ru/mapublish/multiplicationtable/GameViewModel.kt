package ru.mapublish.multiplicationtable

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.MutableLiveData
import android.arch.lifecycle.ViewModel


class GameViewModel : ViewModel() {

    //product to show in the table
    private val _product = MutableLiveData<Int>()
    val product: LiveData<Int>
        get() = _product

    private val _correct = MutableLiveData<Boolean>()
    val correct: LiveData<Boolean>
        get() = _correct

    init {
        _product.value = 0
    }


    // keeps all the numbers that will be shown in the table depending on the current stage
    private lateinit var _productList: MutableList<Int>


    private fun nextNumber() {
        if (_productList.isEmpty()) //TODO goNextStage()
        else _product.value = _productList.removeAt(0)
    }


    /**
     * adds next products to the productList with each Stage and shuffles them
     */
    private fun resetList(stage: Int) {
        _productList = when (stage) {
            1 -> Constants.PRODUCTS_STAGE_ONE
            2 -> Constants.PRODUCTS_STAGE_TWO
            else -> Constants.PRODUCTS_STAGE_ONE
        }
        _productList.shuffle()
    }

    /**
     * attached to the sendAnswer button in XML. Checks if the player's answer was correct and assigns true or false to the _correct field
     */
    fun validateAnswer(answer: String) {
        _correct.value = answer == _product.toString()
    }


}